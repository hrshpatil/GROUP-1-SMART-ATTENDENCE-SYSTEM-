"""
Face recognition preparation service.

No recognition model is wired in at this stage — this module only
crops each detected face region out of the grayscale frame and
normalizes it to a standard size, so a recognizer (LBPH, an embedding
model, etc.) can be dropped in later without changing the detection or
API layers. `recognize()` is a stub that always reports
"not_implemented" until that model exists.
"""

import cv2
import numpy as np

from .face_detection_service import FaceBox

STANDARD_FACE_SIZE = (200, 200)  # (width, height)


class FaceRecognitionPrepService:
    @staticmethod
    def extract_face_crops(gray_frame: np.ndarray, faces: list[FaceBox]) -> list[np.ndarray]:
        """Crop and normalize each detected face region to a standard size."""
        crops: list[np.ndarray] = []
        for face in faces:
            crop = gray_frame[face.y : face.y + face.height, face.x : face.x + face.width]
            if crop.size == 0:
                continue
            normalized = cv2.resize(crop, STANDARD_FACE_SIZE, interpolation=cv2.INTER_AREA)
            crops.append(normalized)
        return crops

    @staticmethod
    def recognize(face_crop: np.ndarray) -> dict:
        """
        Placeholder for the future recognition step.

        Always returns a "not_implemented" result today. Replace this
        with a trained recognizer to return a real student match.
        """
        return {
            "student_id": None,
            "name": None,
            "confidence": None,
            "status": "not_implemented",
        }


face_recognition_prep_service = FaceRecognitionPrepService()
