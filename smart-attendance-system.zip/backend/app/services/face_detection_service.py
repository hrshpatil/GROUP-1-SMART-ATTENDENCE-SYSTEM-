"""
Face detection service.

Uses OpenCV's built-in Haar Cascade classifier — a classical, CPU-only
detector that ships with OpenCV itself, so no model download and no
network access are required. This intentionally stops short of any
deep-learning detector; it's the first stage of the pipeline and can be
swapped out later behind the same `detect()` interface.
"""

import os
import time
from dataclasses import dataclass

import cv2
import numpy as np

from ..core.config import settings

# BGR order (OpenCV) equivalent of the frontend's accent teal (#29d9c2).
ACCENT_TEAL_BGR = (194, 217, 41)


@dataclass
class FaceBox:
    x: int
    y: int
    width: int
    height: int


class FaceDetectionService:
    def __init__(self) -> None:
        cascade_path = os.path.join(
            cv2.data.haarcascades, "haarcascade_frontalface_default.xml"
        )
        self._cascade = cv2.CascadeClassifier(cascade_path)
        if self._cascade.empty():
            raise RuntimeError(
                f"Failed to load Haar Cascade classifier from '{cascade_path}'. "
                "Check the OpenCV installation."
            )

    def detect(self, gray_frame: np.ndarray) -> tuple[list[FaceBox], float]:
        """Run detection on a preprocessed grayscale frame.

        Returns a tuple of (detected faces, elapsed time in milliseconds).
        """
        start = time.perf_counter()
        min_size = (settings.HAAR_MIN_SIZE, settings.HAAR_MIN_SIZE)

        detections = self._cascade.detectMultiScale(
            gray_frame,
            scaleFactor=settings.HAAR_SCALE_FACTOR,
            minNeighbors=settings.HAAR_MIN_NEIGHBORS,
            minSize=min_size,
        )
        elapsed_ms = (time.perf_counter() - start) * 1000

        faces = [
            FaceBox(x=int(x), y=int(y), width=int(w), height=int(h))
            for (x, y, w, h) in detections
        ]
        # Largest box first — usually the closest / primary face in frame.
        faces.sort(key=lambda f: f.width * f.height, reverse=True)
        return faces, elapsed_ms

    @staticmethod
    def draw_boxes(frame: np.ndarray, faces: list[FaceBox]) -> np.ndarray:
        """Return a copy of `frame` annotated with a bounding box per face."""
        annotated = frame.copy()
        for i, face in enumerate(faces):
            top_left = (face.x, face.y)
            bottom_right = (face.x + face.width, face.y + face.height)
            cv2.rectangle(annotated, top_left, bottom_right, ACCENT_TEAL_BGR, 2)

            label = f"Face {i + 1}"
            label_origin = (face.x, max(face.y - 8, 12))
            cv2.putText(
                annotated,
                label,
                label_origin,
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                ACCENT_TEAL_BGR,
                1,
                cv2.LINE_AA,
            )
        return annotated


# The cascade classifier is loaded once and reused across requests rather
# than being re-read from disk on every call.
face_detection_service = FaceDetectionService()
