"""
Image / frame processing service.

This is the boundary between "raw bytes coming from the client" (a
browser camera capture, an uploaded file, a base64 data URL) and the
OpenCV-ready NumPy arrays the rest of the backend works with. It also
holds the shared preprocessing steps (grayscale conversion, contrast
normalization) applied before detection.
"""

import base64
import re

import cv2
import numpy as np

from ..core.config import settings
from ..utils.exceptions import ImageTooLargeError, InvalidImageError

_DATA_URL_PATTERN = re.compile(r"^data:image/\w+;base64,")


class ImageService:
    @staticmethod
    def decode_base64_image(data: str) -> np.ndarray:
        """Decode a base64 string (with or without a data: URL prefix) into a BGR frame."""
        if not data or not data.strip():
            raise InvalidImageError("Received an empty image payload.")

        cleaned = _DATA_URL_PATTERN.sub("", data.strip())
        try:
            raw_bytes = base64.b64decode(cleaned, validate=False)
        except Exception as exc:  # noqa: BLE001 - any decode failure means bad input
            raise InvalidImageError("Could not decode base64 image data.") from exc

        return ImageService.decode_bytes(raw_bytes)

    @staticmethod
    def decode_bytes(raw_bytes: bytes) -> np.ndarray:
        """Decode raw image bytes (e.g. an uploaded file) into a BGR OpenCV frame."""
        if not raw_bytes:
            raise InvalidImageError("Received an empty image payload.")

        size_mb = len(raw_bytes) / (1024 * 1024)
        if size_mb > settings.MAX_IMAGE_SIZE_MB:
            raise ImageTooLargeError(
                f"Image is {size_mb:.1f}MB, which exceeds the "
                f"{settings.MAX_IMAGE_SIZE_MB}MB limit."
            )

        buffer = np.frombuffer(raw_bytes, dtype=np.uint8)
        frame = cv2.imdecode(buffer, cv2.IMREAD_COLOR)

        if frame is None:
            raise InvalidImageError(
                "The file could not be read as an image. Supported formats "
                "include JPEG and PNG."
            )

        height, width = frame.shape[:2]
        if max(height, width) > settings.MAX_IMAGE_DIMENSION:
            raise ImageTooLargeError(
                f"Image dimensions ({width}x{height}) exceed the "
                f"{settings.MAX_IMAGE_DIMENSION}px limit."
            )

        return frame

    @staticmethod
    def to_grayscale(frame: np.ndarray) -> np.ndarray:
        """Convert a BGR frame to a contrast-normalized grayscale frame for detection."""
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        # Histogram equalization helps Haar Cascade detection under
        # uneven or low lighting.
        return cv2.equalizeHist(gray)

    @staticmethod
    def encode_to_base64(frame: np.ndarray, fmt: str = ".jpg") -> str:
        """Encode a BGR frame into a base64 data URL for inclusion in a response."""
        success, buffer = cv2.imencode(fmt, frame)
        if not success:
            raise InvalidImageError("Failed to encode the processed image.")
        mime = "image/jpeg" if fmt == ".jpg" else "image/png"
        encoded = base64.b64encode(buffer).decode("utf-8")
        return f"data:{mime};base64,{encoded}"
