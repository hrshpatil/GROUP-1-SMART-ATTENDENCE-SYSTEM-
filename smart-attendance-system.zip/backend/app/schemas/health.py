from pydantic import BaseModel


class HealthResponse(BaseModel):
    status: str
    service: str
    version: str
    opencv_version: str
    timestamp: str
