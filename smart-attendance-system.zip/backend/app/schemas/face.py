from pydantic import BaseModel, Field


class FaceBoxSchema(BaseModel):
    x: int
    y: int
    width: int
    height: int


class FacePrepSchema(BaseModel):
    """Metadata about a face crop prepared for a future recognition step."""

    width: int
    height: int
    status: str = "not_implemented"


class FaceDetectionResponse(BaseModel):
    success: bool = True
    face_count: int
    faces: list[FaceBoxSchema]
    image_width: int
    image_height: int
    processing_time_ms: float
    annotated_image: str | None = Field(
        default=None,
        description="Base64 data URL of the image with bounding boxes drawn, if requested.",
    )
    prepared_faces: list[FacePrepSchema] = Field(
        default_factory=list,
        description="Standardized face crops ready for a future recognition model.",
    )


class Base64ImageRequest(BaseModel):
    image: str = Field(..., description="Base64-encoded image, with or without a data: URL prefix.")
    return_image: bool = Field(default=True, description="Include the annotated image in the response.")


class ErrorResponse(BaseModel):
    success: bool = False
    error: str
    detail: str | None = None
