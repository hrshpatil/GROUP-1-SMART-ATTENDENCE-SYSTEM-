"""
Application configuration.

Values are read from environment variables so the service can be
configured without code changes, but every setting has a sensible
default for local development.
"""

import os


class Settings:
    APP_NAME: str = "Smart Attendance - Face Service"
    APP_VERSION: str = "0.1.0"

    HOST: str = os.getenv("HOST", "0.0.0.0")
    PORT: int = int(os.getenv("PORT", "8000"))

    # Comma-separated list of origins allowed to call this API.
    # Defaults cover the Vite dev server used by the frontend.
    ALLOWED_ORIGINS: list[str] = [
        origin.strip()
        for origin in os.getenv(
            "ALLOWED_ORIGINS",
            "http://localhost:5173,http://127.0.0.1:5173",
        ).split(",")
        if origin.strip()
    ]

    # Haar Cascade detection tuning.
    HAAR_SCALE_FACTOR: float = float(os.getenv("HAAR_SCALE_FACTOR", "1.1"))
    HAAR_MIN_NEIGHBORS: int = int(os.getenv("HAAR_MIN_NEIGHBORS", "5"))
    HAAR_MIN_SIZE: int = int(os.getenv("HAAR_MIN_SIZE", "30"))

    # Upload guard rails.
    MAX_IMAGE_SIZE_MB: float = float(os.getenv("MAX_IMAGE_SIZE_MB", "8"))
    MAX_IMAGE_DIMENSION: int = int(os.getenv("MAX_IMAGE_DIMENSION", "2000"))


settings = Settings()
