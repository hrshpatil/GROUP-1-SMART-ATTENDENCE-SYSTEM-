"""
Smart Attendance — Face Service.

A local FastAPI + OpenCV backend that performs face detection for the
Smart Attendance frontend. Everything runs on-device: no cloud APIs,
no external model downloads at request time, no data leaves the
machine.
"""

import logging

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .api.routes import face, health
from .core.config import settings
from .utils.exceptions import ImageTooLargeError, InvalidImageError

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("face_service")

app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description=(
        "Local, OpenCV-based face detection service for the Smart Attendance "
        "System. All image processing happens on this machine."
    ),
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---- Error handling -------------------------------------------------------
# Custom exceptions are translated into predictable, structured JSON so the
# frontend always gets a consistent error shape. FastAPI's own handling of
# HTTPException / validation errors (404s, 422s) is unaffected — those stay
# on their own, more specific handlers.


@app.exception_handler(InvalidImageError)
async def handle_invalid_image(request: Request, exc: InvalidImageError) -> JSONResponse:
    logger.warning("Invalid image on %s: %s", request.url.path, exc.message)
    return JSONResponse(
        status_code=400,
        content={"success": False, "error": "invalid_image", "detail": exc.message},
    )


@app.exception_handler(ImageTooLargeError)
async def handle_image_too_large(request: Request, exc: ImageTooLargeError) -> JSONResponse:
    logger.warning("Image too large on %s: %s", request.url.path, exc.message)
    return JSONResponse(
        status_code=413,
        content={"success": False, "error": "image_too_large", "detail": exc.message},
    )


@app.exception_handler(Exception)
async def handle_unexpected_error(request: Request, exc: Exception) -> JSONResponse:
    logger.exception("Unhandled error on %s", request.url.path)
    return JSONResponse(
        status_code=500,
        content={
            "success": False,
            "error": "internal_error",
            "detail": "An unexpected error occurred while processing the request.",
        },
    )


# ---- Routes -----------------------------------------------------------
app.include_router(health.router, prefix="/api")
app.include_router(face.router, prefix="/api")


@app.get("/", tags=["Root"])
def root() -> dict:
    return {"service": settings.APP_NAME, "docs": "/docs", "health": "/api/health"}
