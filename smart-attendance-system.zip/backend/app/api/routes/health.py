from datetime import datetime, timezone

import cv2
from fastapi import APIRouter

from ...core.config import settings
from ...schemas.health import HealthResponse

router = APIRouter(tags=["Health"])


@router.get("/health", response_model=HealthResponse)
def health_check() -> HealthResponse:
    """Liveness/readiness check for the face service."""
    return HealthResponse(
        status="ok",
        service=settings.APP_NAME,
        version=settings.APP_VERSION,
        opencv_version=cv2.__version__,
        timestamp=datetime.now(timezone.utc).isoformat(),
    )
