import numpy as np
from fastapi import APIRouter, File, Query, UploadFile

from ...schemas.face import (
    Base64ImageRequest,
    FaceBoxSchema,
    FaceDetectionResponse,
    FacePrepSchema,
)
from ...services.face_detection_service import face_detection_service
from ...services.face_recognition_prep import face_recognition_prep_service
from ...services.image_service import ImageService
from ...utils.exceptions import InvalidImageError

router = APIRouter(prefix="/face", tags=["Face Detection"])


def _run_detection_pipeline(frame: np.ndarray, return_image: bool) -> FaceDetectionResponse:
    """Shared pipeline: grayscale -> detect -> (optional) annotate -> prepare crops."""
    height, width = frame.shape[:2]
    gray = ImageService.to_grayscale(frame)

    faces, elapsed_ms = face_detection_service.detect(gray)

    annotated_b64 = None
    if return_image:
        annotated_frame = face_detection_service.draw_boxes(frame, faces)
        annotated_b64 = ImageService.encode_to_base64(annotated_frame)

    # Crop + normalize each face so a future recognizer can consume it.
    # No identity is produced yet — see FaceRecognitionPrepService.
    prepared_crops = face_recognition_prep_service.extract_face_crops(gray, faces)
    prepared = [
        FacePrepSchema(width=crop.shape[1], height=crop.shape[0]) for crop in prepared_crops
    ]

    return FaceDetectionResponse(
        face_count=len(faces),
        faces=[FaceBoxSchema(x=f.x, y=f.y, width=f.width, height=f.height) for f in faces],
        image_width=width,
        image_height=height,
        processing_time_ms=round(elapsed_ms, 2),
        annotated_image=annotated_b64,
        prepared_faces=prepared,
    )


@router.post("/detect", response_model=FaceDetectionResponse)
async def detect_faces_from_upload(
    file: UploadFile = File(..., description="An image file (JPEG/PNG) to run detection on."),
    return_image: bool = Query(
        default=True, description="Include the annotated (boxes-drawn) image in the response."
    ),
) -> FaceDetectionResponse:
    """
    Detect faces in an uploaded image using OpenCV Haar Cascade.

    Accepts a multipart file upload (Swagger UI, curl, an HTML form,
    etc.). For a base64 payload — e.g. a browser <canvas> capture — use
    POST /api/face/detect/base64 instead.
    """
    contents = await file.read()
    if not contents:
        raise InvalidImageError("Uploaded file is empty.")

    frame = ImageService.decode_bytes(contents)
    return _run_detection_pipeline(frame, return_image)


@router.post("/detect/base64", response_model=FaceDetectionResponse)
def detect_faces_from_base64(payload: Base64ImageRequest) -> FaceDetectionResponse:
    """
    Detect faces in a base64-encoded image (data URL or raw base64 string).

    Convenient for a browser client that captures a frame to a
    <canvas> and sends `canvas.toDataURL()` directly as JSON.
    """
    frame = ImageService.decode_base64_image(payload.image)
    return _run_detection_pipeline(frame, payload.return_image)
