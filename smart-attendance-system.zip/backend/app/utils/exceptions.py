"""Custom exceptions for predictable, clean API error responses."""


class InvalidImageError(Exception):
    """Raised when image data is missing, corrupt, or cannot be decoded."""

    def __init__(self, message: str = "The provided image could not be processed.") -> None:
        self.message = message
        super().__init__(message)


class ImageTooLargeError(Exception):
    """Raised when an image exceeds the configured size or dimension limits."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)
