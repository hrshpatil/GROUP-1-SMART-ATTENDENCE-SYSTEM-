# Smart Attendance — Backend (Face Detection Service)

A local FastAPI + OpenCV service that performs face detection for the
Smart Attendance System. All image processing runs on this machine —
there are no cloud API calls and no data leaves the server.

## Stack

- Python 3.10+
- FastAPI
- OpenCV (Haar Cascade face detection)
- NumPy

## Project structure

```
backend/
├── app/
│   ├── main.py                     # FastAPI app, CORS, error handlers, routers
│   ├── core/
│   │   └── config.py                # Environment-driven settings
│   ├── api/
│   │   └── routes/
│   │       ├── health.py            # GET /api/health
│   │       └── face.py              # POST /api/face/detect(/base64)
│   ├── services/
│   │   ├── image_service.py         # Decode/preprocess/encode frames
│   │   ├── face_detection_service.py# Haar Cascade detection + box drawing
│   │   └── face_recognition_prep.py # Crops/normalizes faces for a future recognizer
│   ├── schemas/
│   │   ├── health.py
│   │   └── face.py
│   └── utils/
│       └── exceptions.py            # Custom error types
├── run.py                           # `python run.py` dev entrypoint
├── requirements.txt
└── .env.example
```

## Setup

```bash
cd backend
python -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Run

```bash
uvicorn app.main:app --reload --port 8000
```

or

```bash
python run.py
```

The API is then available at **http://localhost:8000**, with interactive
Swagger docs at **http://localhost:8000/docs**.

## Configuration

Copy `.env.example` to `.env` to override any of these (all optional):

| Variable             | Default                                              | Purpose                             |
| -------------------- | ----------------------------------------------------- | ------------------------------------ |
| `HOST`                | `0.0.0.0`                                             | Bind address                         |
| `PORT`                | `8000`                                                | Bind port                            |
| `ALLOWED_ORIGINS`     | `http://localhost:5173,http://127.0.0.1:5173`         | CORS allow-list (comma-separated)    |
| `HAAR_SCALE_FACTOR`   | `1.1`                                                 | Haar Cascade scale factor            |
| `HAAR_MIN_NEIGHBORS`  | `5`                                                   | Haar Cascade min neighbors           |
| `HAAR_MIN_SIZE`       | `30`                                                  | Minimum face size (px, square)       |
| `MAX_IMAGE_SIZE_MB`   | `8`                                                   | Reject uploads larger than this      |
| `MAX_IMAGE_DIMENSION` | `2000`                                                | Reject images wider/taller than this |

## API

### `GET /api/health`

Liveness/readiness check.

```json
{
  "status": "ok",
  "service": "Smart Attendance - Face Service",
  "version": "0.1.0",
  "opencv_version": "4.10.0",
  "timestamp": "2026-09-08T09:00:00+00:00"
}
```

### `POST /api/face/detect`

Multipart file upload. Query param `return_image` (default `true`) controls
whether the annotated (boxes-drawn) image is included in the response.

```bash
curl -X POST "http://localhost:8000/api/face/detect?return_image=true" \
  -F "file=@sample.jpg"
```

### `POST /api/face/detect/base64`

JSON body, for clients that already have a base64 frame (e.g. a browser
`<canvas>` capture via `canvas.toDataURL()`).

```bash
curl -X POST "http://localhost:8000/api/face/detect/base64" \
  -H "Content-Type: application/json" \
  -d '{"image": "data:image/png;base64,iVBORw0KGgo...", "return_image": true}'
```

Both endpoints return the same shape:

```json
{
  "success": true,
  "face_count": 1,
  "faces": [{ "x": 120, "y": 80, "width": 140, "height": 140 }],
  "image_width": 640,
  "image_height": 480,
  "processing_time_ms": 12.4,
  "annotated_image": "data:image/jpeg;base64,...",
  "prepared_faces": [{ "width": 200, "height": 200, "status": "not_implemented" }]
}
```

`prepared_faces` reflects the face-recognition **preparation** step
(each detected face is cropped and resized to a standard 200×200
grayscale image) — no identity is produced yet. That's intentionally
out of scope for this stage; see `face_recognition_prep.py`.

### Error responses

Errors are returned as structured JSON rather than raw tracebacks:

```json
{ "success": false, "error": "invalid_image", "detail": "The file could not be read as an image..." }
```

| Status | `error`           | When                                          |
| ------ | ------------------ | ---------------------------------------------- |
| 400    | `invalid_image`     | Missing, empty, or corrupt/unreadable image     |
| 413    | `image_too_large`   | Exceeds `MAX_IMAGE_SIZE_MB` / `MAX_IMAGE_DIMENSION` |
| 422    | (FastAPI default)   | Missing/malformed request fields                |
| 500    | `internal_error`    | Unexpected server-side error (logged server-side) |

## Connecting the frontend

The frontend needs no redesign to talk to this service — two small, additive
pieces were added purely for connectivity:

- `vite.config.ts` proxies `/api/*` to `http://127.0.0.1:8000` in dev, so the
  app can call relative `/api/...` paths with no CORS setup needed.
- `src/lib/api.ts` is a typed fetch client for `/api/health` and
  `/api/face/detect(/base64)`, configurable via `VITE_API_BASE_URL`
  (see the frontend's `.env.example`). It is **not** wired into any page —
  the Live Attendance UI still runs its mock cycle — so this stage adds
  connectivity without changing existing behavior or design.

## Notes / scope

- Detection uses OpenCV's built-in **Haar Cascade** classifier — a classical,
  CPU-only detector bundled with OpenCV. No deep-learning model, no GPU,
  no external downloads.
- `face_recognition_prep.py` only crops and normalizes faces so a real
  recognizer can be plugged in later behind the same interface — it does
  not identify anyone yet.
- This service is stateless: it does not persist images or write to any
  database. Wiring it into attendance records is a later step.
