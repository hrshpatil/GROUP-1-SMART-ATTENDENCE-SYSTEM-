import { createContext, useContext, useMemo, useState, type ReactNode } from "react";
import { students as initialStudents } from "../data/dummyData";
import type { Student, StudentFormValues } from "../types";

const avatarColors = ["#29d9c2", "#f2a950", "#f2685f", "#8a93a6", "#35d399", "#4ce4d1"];

interface StudentsContextValue {
  students: Student[];
  addStudent: (values: StudentFormValues, photo: string | null) => Student;
  updateStudent: (id: string, values: StudentFormValues) => void;
  deleteStudent: (id: string) => void;
}

const StudentsContext = createContext<StudentsContextValue | undefined>(undefined);

function todayLabel(): string {
  return new Date().toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

export function StudentsProvider({ children }: { children: ReactNode }) {
  const [students, setStudents] = useState<Student[]>(initialStudents);

  const addStudent = (values: StudentFormValues, photo: string | null) => {
    const newStudent: Student = {
      id: `STU-${String(students.length + 1).padStart(3, "0")}`,
      rollNo: values.rollNo,
      name: values.name,
      department: values.department,
      semester: values.semester,
      batch: "2023 - 2027",
      email: values.email,
      enrolledOn: todayLabel(),
      faceSamples: photo ? 1 : 0,
      status: "absent",
      enrollmentStatus: "active",
      photo,
      avatarColor: avatarColors[students.length % avatarColors.length],
    };
    setStudents((prev) => [newStudent, ...prev]);
    return newStudent;
  };

  const updateStudent = (id: string, values: StudentFormValues) => {
    setStudents((prev) =>
      prev.map((s) =>
        s.id === id
          ? { ...s, rollNo: values.rollNo, name: values.name, department: values.department, semester: values.semester, email: values.email }
          : s
      )
    );
  };

  const deleteStudent = (id: string) => {
    setStudents((prev) => prev.filter((s) => s.id !== id));
  };

  const value = useMemo(
    () => ({ students, addStudent, updateStudent, deleteStudent }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [students]
  );

  return <StudentsContext.Provider value={value}>{children}</StudentsContext.Provider>;
}

export function useStudents() {
  const ctx = useContext(StudentsContext);
  if (!ctx) throw new Error("useStudents must be used within StudentsProvider");
  return ctx;
}
