import type {
  AttendanceRecord,
  DepartmentBreakdown,
  Student,
  WeeklyAttendancePoint,
} from "../types";

const avatarColors = [
  "#29d9c2",
  "#f2a950",
  "#f2685f",
  "#8a93a6",
  "#35d399",
  "#4ce4d1",
];

const firstNames = [
  "Aarav", "Isha", "Kabir", "Meera", "Rohan", "Ananya", "Vikram", "Priya",
  "Aditya", "Sneha", "Arjun", "Divya", "Karan", "Neha", "Yash", "Pooja",
  "Rahul", "Simran", "Dev", "Tanya", "Nikhil", "Riya", "Sahil", "Kavya",
];
const lastNames = [
  "Sharma", "Verma", "Iyer", "Gupta", "Nair", "Rao", "Mehta", "Kapoor",
  "Joshi", "Reddy", "Singh", "Bose", "Malhotra", "Chawla", "Pillai", "Desai",
];

export const departments = [
  "Computer Science",
  "Electronics & Comm.",
  "Information Tech.",
  "Mechanical",
];

const statuses: Student["status"][] = ["present", "present", "present", "absent", "late"];
const enrollmentStatuses: Student["enrollmentStatus"][] = [
  "active",
  "active",
  "active",
  "active",
  "inactive",
];

function seededRandom(seed: number) {
  let value = seed;
  return () => {
    value = (value * 9301 + 49297) % 233280;
    return value / 233280;
  };
}

const rand = seededRandom(42);

export const students: Student[] = Array.from({ length: 32 }).map((_, i) => {
  const first = firstNames[i % firstNames.length];
  const last = lastNames[Math.floor(rand() * lastNames.length)];
  const dept = departments[i % departments.length];
  const status = statuses[Math.floor(rand() * statuses.length)];
  const enrollmentStatus = enrollmentStatuses[Math.floor(rand() * enrollmentStatuses.length)];
  return {
    id: `STU-${String(i + 1).padStart(3, "0")}`,
    rollNo: `${dept.slice(0, 2).toUpperCase()}${2023000 + i}`,
    name: `${first} ${last}`,
    department: dept,
    semester: 1 + (i % 8),
    batch: i % 2 === 0 ? "2023 - 2027" : "2022 - 2026",
    email: `${first.toLowerCase()}.${last.toLowerCase()}@college.edu`,
    enrolledOn: `${String(1 + (i % 28)).padStart(2, "0")} Jan 2024`,
    faceSamples: 15 + Math.floor(rand() * 10),
    status,
    enrollmentStatus,
    photo: null,
    avatarColor: avatarColors[i % avatarColors.length],
  };
});

export const attendanceRecords: AttendanceRecord[] = students
  .slice(0, 20)
  .map((s, i) => {
    const hour = 9 + Math.floor(rand() * 2);
    const minute = Math.floor(rand() * 60);
    return {
      id: `ATT-${String(i + 1).padStart(4, "0")}`,
      studentId: s.id,
      studentName: s.name,
      rollNo: s.rollNo,
      department: s.department,
      date: "08 Sep 2026",
      time: `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")} AM`,
      status: s.status,
      confidence: Math.round((92 + rand() * 7.8) * 10) / 10,
    };
  });

export const weeklyAttendance: WeeklyAttendancePoint[] = [
  { day: "Mon", present: 118, absent: 12 },
  { day: "Tue", present: 124, absent: 6 },
  { day: "Wed", present: 109, absent: 21 },
  { day: "Thu", present: 121, absent: 9 },
  { day: "Fri", present: 126, absent: 4 },
  { day: "Sat", present: 98, absent: 32 },
];

export const departmentBreakdown: DepartmentBreakdown[] = [
  { department: "Computer Science", value: 38 },
  { department: "Information Tech.", value: 27 },
  { department: "Electronics & Comm.", value: 22 },
  { department: "Mechanical", value: 13 },
];

export const totalStudents = 130;
export const presentToday = 112;
export const absentToday = totalStudents - presentToday;
export const attendancePercentage = Math.round((presentToday / totalStudents) * 1000) / 10;
