import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import './index.css'
import App from './App.tsx'
import { ThemeProvider } from './context/ThemeContext.tsx'
import { StudentsProvider } from './context/StudentsContext.tsx'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ThemeProvider>
      <StudentsProvider>
        <BrowserRouter>
          <App />
        </BrowserRouter>
      </StudentsProvider>
    </ThemeProvider>
  </StrictMode>,
)
