import { Route, Routes } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import Students from "./pages/Students";
import RegisterStudent from "./pages/RegisterStudent";
import LiveAttendance from "./pages/LiveAttendance";
import AttendanceRecords from "./pages/AttendanceRecords";
import Reports from "./pages/Reports";
import Settings from "./pages/Settings";

function App() {
  return (
    <Routes>
      <Route path="/" element={<Dashboard />} />
      <Route path="/students" element={<Students />} />
      <Route path="/register" element={<RegisterStudent />} />
      <Route path="/live-attendance" element={<LiveAttendance />} />
      <Route path="/records" element={<AttendanceRecords />} />
      <Route path="/reports" element={<Reports />} />
      <Route path="/settings" element={<Settings />} />
    </Routes>
  );
}

export default App;
