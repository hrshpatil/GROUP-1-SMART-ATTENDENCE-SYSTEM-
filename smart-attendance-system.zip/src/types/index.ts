export type AttendanceStatus = "present" | "absent" | "late";
export type EnrollmentStatus = "active" | "inactive";

export interface Student {
  id: string;
  rollNo: string;
  name: string;
  department: string;
  semester: number;
  batch: string;
  email: string;
  enrolledOn: string;
  faceSamples: number;
  status: AttendanceStatus;
  enrollmentStatus: EnrollmentStatus;
  photo: string | null;
  avatarColor: string;
}

export interface StudentFormValues {
  rollNo: string;
  name: string;
  department: string;
  semester: number;
  email: string;
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  studentName: string;
  rollNo: string;
  department: string;
  date: string;
  time: string;
  status: AttendanceStatus;
  confidence: number;
}

export interface WeeklyAttendancePoint {
  day: string;
  present: number;
  absent: number;
}

export interface DepartmentBreakdown {
  department: string;
  value: number;
}
