import { useState } from "react";
import { DashboardLayout } from "../components/layout/DashboardLayout";
import { useTheme } from "../context/ThemeContext";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { Input } from "../components/ui/Input";

function Toggle({ checked, onChange }: { checked: boolean; onChange: () => void }) {
  return (
    <button
      onClick={onChange}
      role="switch"
      aria-checked={checked}
      className={`relative h-6 w-11 shrink-0 rounded-full transition-colors duration-200 ${
        checked ? "bg-accent-500" : "bg-base-600"
      }`}
    >
      <span
        className={`absolute top-0.5 h-5 w-5 rounded-full bg-base-50 transition-transform duration-200 ${
          checked ? "translate-x-[22px]" : "translate-x-0.5"
        }`}
      />
    </button>
  );
}

function SettingRow({
  title,
  description,
  control,
}: {
  title: string;
  description: string;
  control: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-4 py-4">
      <div>
        <p className="text-sm font-medium text-base-100">{title}</p>
        <p className="mt-0.5 text-xs text-base-400">{description}</p>
      </div>
      {control}
    </div>
  );
}

export default function Settings() {
  const { theme, toggleTheme } = useTheme();
  const [notifications, setNotifications] = useState(true);
  const [autoMark, setAutoMark] = useState(true);
  const [confidenceAlerts, setConfidenceAlerts] = useState(false);

  return (
    <DashboardLayout title="Settings" subtitle="Manage system preferences and camera configuration">
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card className="p-6">
          <h2 className="mb-1 font-display text-base font-semibold text-base-100">Appearance</h2>
          <p className="mb-2 text-sm text-base-400">Choose how Smart Attendance looks on this device.</p>
          <div className="divide-y divide-base-800">
            <SettingRow
              title="Dark theme"
              description="Use a dark, low-glare interface"
              control={<Toggle checked={theme === "dark"} onChange={toggleTheme} />}
            />
            <SettingRow
              title="Push notifications"
              description="Get notified when attendance sessions complete"
              control={<Toggle checked={notifications} onChange={() => setNotifications((v) => !v)} />}
            />
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="mb-1 font-display text-base font-semibold text-base-100">Recognition</h2>
          <p className="mb-2 text-sm text-base-400">Configure how attendance is captured and marked.</p>
          <div className="divide-y divide-base-800">
            <SettingRow
              title="Auto-mark attendance"
              description="Mark students present automatically once recognized"
              control={<Toggle checked={autoMark} onChange={() => setAutoMark((v) => !v)} />}
            />
            <SettingRow
              title="Low-confidence alerts"
              description="Flag detections below the confidence threshold"
              control={<Toggle checked={confidenceAlerts} onChange={() => setConfidenceAlerts((v) => !v)} />}
            />
          </div>
          <div className="mt-2">
            <Input label="Confidence threshold (%)" type="number" defaultValue={85} min={0} max={100} />
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="mb-4 font-display text-base font-semibold text-base-100">Institution details</h2>
          <div className="space-y-4">
            <Input label="Institution name" defaultValue="Government College of Engineering" />
            <Input label="Department" defaultValue="Computer Science & Engineering" />
            <Input label="Admin email" type="email" defaultValue="admin@college.edu" />
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="mb-1 font-display text-base font-semibold text-base-100">Camera source</h2>
          <p className="mb-4 text-sm text-base-400">
            Select which capture device will be used once recognition is implemented.
          </p>
          <label className="block">
            <span className="mb-1.5 block text-sm font-medium text-base-200">Device</span>
            <select
              className="w-full rounded-xl border border-base-600 bg-base-800/60 px-3 py-2.5 text-sm text-base-100 outline-none transition-colors focus:border-accent-500/70"
              defaultValue="webcam"
            >
              <option value="webcam">Built-in webcam</option>
              <option value="usb">External USB camera</option>
              <option value="ip">IP camera (RTSP)</option>
            </select>
          </label>
          <p className="mt-3 rounded-xl border border-amber-500/25 bg-amber-500/10 px-3.5 py-2.5 text-xs text-amber-500">
            Camera integration is not active in this UI preview.
          </p>
        </Card>
      </div>

      <div className="mt-6 flex justify-end gap-3">
        <Button variant="ghost">Reset to defaults</Button>
        <Button>Save changes</Button>
      </div>
    </DashboardLayout>
  );
}
