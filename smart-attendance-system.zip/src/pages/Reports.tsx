import { Download } from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { DashboardLayout } from "../components/layout/DashboardLayout";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { departmentBreakdown, weeklyAttendance } from "../data/dummyData";

const pieColors = ["#29d9c2", "#4ce4d1", "#f2a950", "#8a93a6"];

const tooltipStyle = {
  contentStyle: {
    background: "#111a2c",
    border: "1px solid #24304a",
    borderRadius: 12,
    fontSize: 12,
    fontFamily: "Inter",
  },
  labelStyle: { color: "#e8ecf1", fontWeight: 600, marginBottom: 4 },
};

export default function Reports() {
  return (
    <DashboardLayout title="Reports" subtitle="Attendance trends and department-wise analytics">
      <div className="mb-6 flex justify-end">
        <Button variant="secondary" icon={<Download size={16} />}>
          Export report (PDF)
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-5">
        <Card className="p-5 xl:col-span-3">
          <h2 className="mb-4 font-display text-base font-semibold text-base-100">
            Present vs absent — daily comparison
          </h2>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={weeklyAttendance} margin={{ left: -18 }}>
                <CartesianGrid vertical={false} stroke="#182238" />
                <XAxis
                  dataKey="day"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "#8a93a6", fontSize: 12, fontFamily: "JetBrains Mono" }}
                />
                <YAxis
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "#8a93a6", fontSize: 12, fontFamily: "JetBrains Mono" }}
                  width={32}
                />
                <Tooltip {...tooltipStyle} cursor={{ fill: "rgba(41,217,194,0.06)" }} />
                <Bar dataKey="present" name="Present" fill="#29d9c2" radius={[6, 6, 0, 0]} />
                <Bar dataKey="absent" name="Absent" fill="#f2685f" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-5 xl:col-span-2">
          <h2 className="mb-4 font-display text-base font-semibold text-base-100">
            Enrollment by department
          </h2>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={departmentBreakdown}
                  dataKey="value"
                  nameKey="department"
                  innerRadius={62}
                  outerRadius={92}
                  paddingAngle={3}
                >
                  {departmentBreakdown.map((_, i) => (
                    <Cell key={i} fill={pieColors[i % pieColors.length]} stroke="none" />
                  ))}
                </Pie>
                <Tooltip {...tooltipStyle} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-2 space-y-2">
            {departmentBreakdown.map((d, i) => (
              <div key={d.department} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <span
                    className="h-2.5 w-2.5 rounded-full"
                    style={{ backgroundColor: pieColors[i % pieColors.length] }}
                  />
                  <span className="text-base-300">{d.department}</span>
                </div>
                <span className="font-mono text-base-100">{d.value}%</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card className="mt-6 p-5">
        <h2 className="mb-4 font-display text-base font-semibold text-base-100">Summary</h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <div className="rounded-xl border border-base-700 bg-base-800/40 p-4">
            <p className="text-xs text-base-400">Average weekly attendance</p>
            <p className="mt-1 font-mono text-2xl font-semibold text-base-100">89.4%</p>
          </div>
          <div className="rounded-xl border border-base-700 bg-base-800/40 p-4">
            <p className="text-xs text-base-400">Most punctual department</p>
            <p className="mt-1 font-display text-lg font-semibold text-base-100">
              Computer Science
            </p>
          </div>
          <div className="rounded-xl border border-base-700 bg-base-800/40 p-4">
            <p className="text-xs text-base-400">Model recognition accuracy</p>
            <p className="mt-1 font-mono text-2xl font-semibold text-accent-400">96.8%</p>
          </div>
        </div>
      </Card>
    </DashboardLayout>
  );
}
