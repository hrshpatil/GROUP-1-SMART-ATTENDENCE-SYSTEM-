import { Download, Search } from "lucide-react";
import { useMemo, useState } from "react";
import { DashboardLayout } from "../components/layout/DashboardLayout";
import { Badge } from "../components/ui/Badge";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { Input } from "../components/ui/Input";
import { Table, type Column } from "../components/ui/Table";
import { attendanceRecords } from "../data/dummyData";
import type { AttendanceRecord, AttendanceStatus } from "../types";

const statusFilters: { label: string; value: AttendanceStatus | "all" }[] = [
  { label: "All", value: "all" },
  { label: "Present", value: "present" },
  { label: "Absent", value: "absent" },
  { label: "Late", value: "late" },
];

export default function AttendanceRecords() {
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<AttendanceStatus | "all">("all");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return attendanceRecords.filter((r) => {
      const matchesQuery =
        !q || r.studentName.toLowerCase().includes(q) || r.rollNo.toLowerCase().includes(q);
      const matchesStatus = status === "all" || r.status === status;
      return matchesQuery && matchesStatus;
    });
  }, [query, status]);

  const columns: Column<AttendanceRecord>[] = [
    { header: "Date", accessor: (r) => <span className="font-mono text-xs">{r.date}</span> },
    {
      header: "Student",
      accessor: (r) => (
        <div>
          <p className="font-medium text-base-100">{r.studentName}</p>
          <p className="font-mono text-xs text-base-400">{r.rollNo}</p>
        </div>
      ),
    },
    { header: "Department", accessor: (r) => r.department },
    { header: "Time", accessor: (r) => <span className="font-mono">{r.time}</span> },
    {
      header: "Confidence",
      accessor: (r) => <span className="font-mono text-accent-400">{r.confidence}%</span>,
    },
    { header: "Status", accessor: (r) => <Badge status={r.status} /> },
  ];

  return (
    <DashboardLayout title="Attendance Records" subtitle="Search and review historical attendance logs">
      <Card className="p-5">
        <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex-1 sm:max-w-xs">
            <Input
              placeholder="Search by name or roll no"
              icon={<Search size={16} />}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex rounded-xl border border-base-700 bg-base-800/40 p-1">
              {statusFilters.map((f) => (
                <button
                  key={f.value}
                  onClick={() => setStatus(f.value)}
                  className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-colors ${
                    status === f.value
                      ? "bg-accent-500 text-base-950"
                      : "text-base-300 hover:text-base-100"
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
            <Button variant="secondary" icon={<Download size={16} />}>
              Export
            </Button>
          </div>
        </div>

        <Table columns={columns} data={filtered} keyExtractor={(r) => r.id} />
      </Card>
    </DashboardLayout>
  );
}
