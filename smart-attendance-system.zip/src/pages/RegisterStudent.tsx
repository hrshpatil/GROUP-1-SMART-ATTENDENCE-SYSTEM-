import { AnimatePresence, motion } from "framer-motion";
import { Camera, CheckCircle2, RotateCcw, ScanFace, UserPlus } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { DashboardLayout } from "../components/layout/DashboardLayout";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { Input } from "../components/ui/Input";
import { Modal } from "../components/ui/Modal";
import { useStudents } from "../context/StudentsContext";
import { departments } from "../data/dummyData";
import { generateMockCapture } from "../lib/generateMockCapture";
import type { StudentFormValues } from "../types";

const avatarColors = ["#29d9c2", "#f2a950", "#f2685f", "#8a93a6", "#35d399", "#4ce4d1"];

type CaptureState = "idle" | "flashing" | "captured";

function emptyForm(): StudentFormValues {
  return { rollNo: "", name: "", department: departments[0], semester: 1, email: "" };
}

export default function RegisterStudent() {
  const { addStudent } = useStudents();
  const navigate = useNavigate();

  const [values, setValues] = useState<StudentFormValues>(emptyForm());
  const [captureState, setCaptureState] = useState<CaptureState>("idle");
  const [photo, setPhoto] = useState<string | null>(null);
  const [successOpen, setSuccessOpen] = useState(false);
  const [errors, setErrors] = useState<string | null>(null);

  function capturePhoto() {
    if (!values.name.trim()) {
      setErrors("Enter the student's name before capturing a photo.");
      return;
    }
    setErrors(null);
    setCaptureState("flashing");
    window.setTimeout(() => {
      const color = avatarColors[Math.floor(Math.random() * avatarColors.length)];
      setPhoto(generateMockCapture(values.name, color));
      setCaptureState("captured");
    }, 260);
  }

  function retakePhoto() {
    setPhoto(null);
    setCaptureState("idle");
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!photo) {
      setErrors("Capture a photo before registering the student.");
      return;
    }
    setErrors(null);
    addStudent(values, photo);
    setSuccessOpen(true);
  }

  function registerAnother() {
    setSuccessOpen(false);
    setValues(emptyForm());
    setPhoto(null);
    setCaptureState("idle");
  }

  return (
    <DashboardLayout title="Register Student" subtitle="Enroll a new student into the system">
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25, ease: "easeOut" }}
          className="lg:col-span-3"
        >
          <Card className="p-6">
            <h2 className="mb-5 font-display text-base font-semibold text-base-100">Student details</h2>
            <form className="space-y-4" onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <Input
                  label="Student ID"
                  placeholder="e.g. CS2026042"
                  value={values.rollNo}
                  onChange={(e) => setValues((v) => ({ ...v, rollNo: e.target.value }))}
                  required
                />
                <Input
                  label="Student name"
                  placeholder="e.g. Ananya Sharma"
                  value={values.name}
                  onChange={(e) => setValues((v) => ({ ...v, name: e.target.value }))}
                  required
                />
              </div>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <label className="block">
                  <span className="mb-1.5 block text-sm font-medium text-base-200">Department</span>
                  <select
                    required
                    value={values.department}
                    onChange={(e) => setValues((v) => ({ ...v, department: e.target.value }))}
                    className="w-full rounded-xl border border-base-600 bg-base-800/60 px-3 py-2.5 text-sm text-base-100 outline-none transition-colors focus:border-accent-500/70"
                  >
                    {departments.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="block">
                  <span className="mb-1.5 block text-sm font-medium text-base-200">Semester</span>
                  <select
                    required
                    value={values.semester}
                    onChange={(e) => setValues((v) => ({ ...v, semester: Number(e.target.value) }))}
                    className="w-full rounded-xl border border-base-600 bg-base-800/60 px-3 py-2.5 text-sm text-base-100 outline-none transition-colors focus:border-accent-500/70"
                  >
                    {Array.from({ length: 8 }, (_, i) => i + 1).map((s) => (
                      <option key={s} value={s}>
                        Semester {s}
                      </option>
                    ))}
                  </select>
                </label>
              </div>
              <Input
                label="Email (optional)"
                type="email"
                placeholder="student@college.edu"
                value={values.email}
                onChange={(e) => setValues((v) => ({ ...v, email: e.target.value }))}
              />

              <AnimatePresence>
                {errors && (
                  <motion.p
                    initial={{ opacity: 0, y: -4 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -4 }}
                    className="rounded-xl border border-amber-500/25 bg-amber-500/10 px-3.5 py-2.5 text-xs text-amber-500"
                  >
                    {errors}
                  </motion.p>
                )}
              </AnimatePresence>

              <div className="flex justify-end gap-3 pt-2">
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => {
                    setValues(emptyForm());
                    setPhoto(null);
                    setCaptureState("idle");
                    setErrors(null);
                  }}
                >
                  Reset
                </Button>
                <Button type="submit" icon={<UserPlus size={17} />}>
                  Register Student
                </Button>
              </div>
            </form>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25, ease: "easeOut", delay: 0.08 }}
          className="lg:col-span-2"
        >
          <Card className="flex h-full flex-col p-6">
            <h2 className="mb-5 font-display text-base font-semibold text-base-100">Photo capture</h2>

            <div className="corner-brackets brackets-active relative flex aspect-[4/3] items-center justify-center overflow-hidden rounded-2xl border border-base-600 bg-base-950">
              <AnimatePresence mode="wait">
                {captureState !== "captured" ? (
                  <motion.div
                    key="preview"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.15 }}
                    className="absolute inset-0 flex items-center justify-center"
                  >
                    <div className="scan-grid-bg absolute inset-0 opacity-60" />
                    <div className="relative flex flex-col items-center gap-2 text-base-500">
                      <ScanFace size={44} strokeWidth={1.5} />
                      <p className="text-xs">Camera preview placeholder</p>
                    </div>
                    <motion.div
                      className="absolute left-0 right-0 h-0.5 bg-accent-500/70 shadow-[0_0_12px_2px_var(--color-accent-glow)]"
                      initial={{ top: "12%" }}
                      animate={{ top: ["12%", "88%", "12%"] }}
                      transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                    />
                  </motion.div>
                ) : (
                  <motion.img
                    key="captured"
                    src={photo ?? undefined}
                    alt="Captured student"
                    initial={{ opacity: 0, scale: 1.03 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.25 }}
                    className="absolute inset-0 h-full w-full object-cover"
                  />
                )}
              </AnimatePresence>

              {/* Camera flash flicker */}
              <AnimatePresence>
                {captureState === "flashing" && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: [0, 0.9, 0] }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.26 }}
                    className="pointer-events-none absolute inset-0 bg-white"
                  />
                )}
              </AnimatePresence>

              {captureState === "captured" && (
                <span className="absolute right-3 top-3 inline-flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-base-950/80 px-2.5 py-1 text-xs font-medium text-emerald-500 backdrop-blur-sm">
                  <CheckCircle2 size={13} /> Captured
                </span>
              )}
            </div>

            <div className="mt-4 flex gap-3">
              {captureState !== "captured" ? (
                <Button
                  fullWidth
                  icon={<Camera size={17} />}
                  onClick={capturePhoto}
                  disabled={captureState === "flashing"}
                >
                  {captureState === "flashing" ? "Capturing..." : "Capture Photo"}
                </Button>
              ) : (
                <Button fullWidth variant="secondary" icon={<RotateCcw size={17} />} onClick={retakePhoto}>
                  Retake Photo
                </Button>
              )}
            </div>

            <p className="mt-3 text-center text-xs text-base-400">
              Camera and face recognition are not connected — this preview is generated locally.
            </p>
          </Card>
        </motion.div>
      </div>

      <Modal
        open={successOpen}
        onClose={() => setSuccessOpen(false)}
        title="Student registered"
        description="This is a UI preview — data is stored only in local frontend state."
      >
        <div className="mb-5 flex items-center gap-3 rounded-xl border border-emerald-500/25 bg-emerald-500/10 p-3.5">
          <CheckCircle2 className="shrink-0 text-emerald-500" size={20} />
          <p className="text-sm text-base-200">
            <span className="font-medium text-base-100">{values.name}</span> has been added to the
            students list.
          </p>
        </div>
        <div className="flex gap-3">
          <Button fullWidth variant="secondary" onClick={registerAnother}>
            Register another
          </Button>
          <Button fullWidth onClick={() => navigate("/students")}>
            View students
          </Button>
        </div>
      </Modal>
    </DashboardLayout>
  );
}
