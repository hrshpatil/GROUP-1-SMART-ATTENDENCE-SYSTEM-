import { AnimatePresence, motion } from "framer-motion";
import {
  AlertTriangle,
  Eye,
  Filter,
  Pencil,
  Search,
  Trash2,
  UserPlus,
  X,
} from "lucide-react";
import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { DashboardLayout } from "../components/layout/DashboardLayout";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { Input } from "../components/ui/Input";
import { Modal } from "../components/ui/Modal";
import { departments } from "../data/dummyData";
import { useStudents } from "../context/StudentsContext";
import type { EnrollmentStatus, Student, StudentFormValues } from "../types";

function initials(name: string) {
  return name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

function EnrollmentBadge({ status }: { status: EnrollmentStatus }) {
  const active = status === "active";
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium ${
        active
          ? "border-emerald-500/25 bg-emerald-500/10 text-emerald-500"
          : "border-base-600 bg-base-800 text-base-400"
      }`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${active ? "bg-emerald-500" : "bg-base-500"}`} />
      {active ? "Active" : "Inactive"}
    </span>
  );
}

const rowVariants = {
  hidden: { opacity: 0, y: 6 },
  visible: { opacity: 1, y: 0 },
  exit: { opacity: 0, x: -12, transition: { duration: 0.15 } },
};

interface StudentFormState extends StudentFormValues {}

function emptyForm(): StudentFormState {
  return { rollNo: "", name: "", department: departments[0], semester: 1, email: "" };
}

function StudentForm({
  values,
  onChange,
}: {
  values: StudentFormState;
  onChange: (values: StudentFormState) => void;
}) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Input
          label="Student ID"
          value={values.rollNo}
          onChange={(e) => onChange({ ...values, rollNo: e.target.value })}
          placeholder="e.g. CS2026042"
          required
        />
        <Input
          label="Student name"
          value={values.name}
          onChange={(e) => onChange({ ...values, name: e.target.value })}
          placeholder="e.g. Ananya Sharma"
          required
        />
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <label className="block">
          <span className="mb-1.5 block text-sm font-medium text-base-200">Department</span>
          <select
            required
            value={values.department}
            onChange={(e) => onChange({ ...values, department: e.target.value })}
            className="w-full rounded-xl border border-base-600 bg-base-800/60 px-3 py-2.5 text-sm text-base-100 outline-none transition-colors focus:border-accent-500/70"
          >
            {departments.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
        </label>
        <label className="block">
          <span className="mb-1.5 block text-sm font-medium text-base-200">Semester</span>
          <select
            required
            value={values.semester}
            onChange={(e) => onChange({ ...values, semester: Number(e.target.value) })}
            className="w-full rounded-xl border border-base-600 bg-base-800/60 px-3 py-2.5 text-sm text-base-100 outline-none transition-colors focus:border-accent-500/70"
          >
            {Array.from({ length: 8 }, (_, i) => i + 1).map((s) => (
              <option key={s} value={s}>
                Semester {s}
              </option>
            ))}
          </select>
        </label>
      </div>
      <Input
        label="Email (optional)"
        type="email"
        value={values.email}
        onChange={(e) => onChange({ ...values, email: e.target.value })}
        placeholder="student@college.edu"
      />
    </div>
  );
}

export default function Students() {
  const { students, updateStudent, deleteStudent } = useStudents();
  const [query, setQuery] = useState("");
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [departmentFilter, setDepartmentFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<EnrollmentStatus | "all">("all");

  const [viewing, setViewing] = useState<Student | null>(null);
  const [editing, setEditing] = useState<Student | null>(null);
  const [editValues, setEditValues] = useState<StudentFormState>(emptyForm());
  const [deleting, setDeleting] = useState<Student | null>(null);

  const navigate = useNavigate();

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return students.filter((s) => {
      const matchesQuery =
        !q ||
        s.name.toLowerCase().includes(q) ||
        s.rollNo.toLowerCase().includes(q) ||
        s.department.toLowerCase().includes(q);
      const matchesDept = departmentFilter === "all" || s.department === departmentFilter;
      const matchesStatus = statusFilter === "all" || s.enrollmentStatus === statusFilter;
      return matchesQuery && matchesDept && matchesStatus;
    });
  }, [students, query, departmentFilter, statusFilter]);

  function openEdit(student: Student) {
    setEditing(student);
    setEditValues({
      rollNo: student.rollNo,
      name: student.name,
      department: student.department,
      semester: student.semester,
      email: student.email,
    });
  }

  function saveEdit() {
    if (!editing) return;
    updateStudent(editing.id, editValues);
    setEditing(null);
  }

  function confirmDelete() {
    if (!deleting) return;
    deleteStudent(deleting.id);
    setDeleting(null);
  }

  return (
    <DashboardLayout title="Students" subtitle={`${students.length} enrolled students`}>
      <Card className="p-5">
        <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex-1 sm:max-w-xs">
            <Input
              placeholder="Search by name, ID, department"
              icon={<Search size={16} />}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant={filtersOpen ? "primary" : "secondary"}
              icon={<Filter size={16} />}
              onClick={() => setFiltersOpen((v) => !v)}
            >
              Filters
            </Button>
            <Button icon={<UserPlus size={16} />} onClick={() => navigate("/register")}>
              Register Student
            </Button>
          </div>
        </div>

        <AnimatePresence initial={false}>
          {filtersOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
              className="overflow-hidden"
            >
              <div className="mb-5 grid grid-cols-1 gap-3 rounded-xl border border-base-700 bg-base-800/40 p-4 sm:grid-cols-2">
                <label className="block">
                  <span className="mb-1.5 block text-xs font-medium text-base-300">Department</span>
                  <select
                    value={departmentFilter}
                    onChange={(e) => setDepartmentFilter(e.target.value)}
                    className="w-full rounded-xl border border-base-600 bg-base-800/60 px-3 py-2 text-sm text-base-100 outline-none focus:border-accent-500/70"
                  >
                    <option value="all">All departments</option>
                    {departments.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="block">
                  <span className="mb-1.5 block text-xs font-medium text-base-300">Status</span>
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value as EnrollmentStatus | "all")}
                    className="w-full rounded-xl border border-base-600 bg-base-800/60 px-3 py-2 text-sm text-base-100 outline-none focus:border-accent-500/70"
                  >
                    <option value="all">All statuses</option>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </label>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] border-collapse text-left text-sm">
            <thead>
              <tr className="border-b border-base-700 text-xs uppercase tracking-wide text-base-400">
                <th className="whitespace-nowrap px-4 py-3 font-medium">Student ID</th>
                <th className="whitespace-nowrap px-4 py-3 font-medium">Name</th>
                <th className="whitespace-nowrap px-4 py-3 font-medium">Department</th>
                <th className="whitespace-nowrap px-4 py-3 font-medium">Semester</th>
                <th className="whitespace-nowrap px-4 py-3 font-medium">Registration Date</th>
                <th className="whitespace-nowrap px-4 py-3 font-medium">Status</th>
                <th className="whitespace-nowrap px-4 py-3 text-right font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              <AnimatePresence initial={false}>
                {filtered.length === 0 ? (
                  <motion.tr key="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                    <td colSpan={7} className="px-4 py-10 text-center text-base-400">
                      No students match your search or filters.
                    </td>
                  </motion.tr>
                ) : (
                  filtered.map((row) => (
                    <motion.tr
                      key={row.id}
                      layout
                      variants={rowVariants}
                      initial="hidden"
                      animate="visible"
                      exit="exit"
                      transition={{ duration: 0.18 }}
                      className="border-b border-base-800/70 text-base-200 last:border-b-0 hover:bg-base-800/40"
                    >
                      <td className="whitespace-nowrap px-4 py-3.5 font-mono text-xs">{row.rollNo}</td>
                      <td className="whitespace-nowrap px-4 py-3.5">
                        <div className="flex items-center gap-3">
                          {row.photo ? (
                            <img
                              src={row.photo}
                              alt={row.name}
                              className="h-9 w-9 shrink-0 rounded-lg object-cover"
                            />
                          ) : (
                            <span
                              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg font-display text-xs font-semibold text-base-950"
                              style={{ backgroundColor: row.avatarColor }}
                            >
                              {initials(row.name)}
                            </span>
                          )}
                          <div>
                            <p className="font-medium text-base-100">{row.name}</p>
                            <p className="text-xs text-base-400">{row.email || "No email on file"}</p>
                          </div>
                        </div>
                      </td>
                      <td className="whitespace-nowrap px-4 py-3.5">{row.department}</td>
                      <td className="whitespace-nowrap px-4 py-3.5">
                        <span className="font-mono">{row.semester}</span>
                      </td>
                      <td className="whitespace-nowrap px-4 py-3.5 font-mono text-xs">{row.enrolledOn}</td>
                      <td className="whitespace-nowrap px-4 py-3.5">
                        <EnrollmentBadge status={row.enrollmentStatus} />
                      </td>
                      <td className="whitespace-nowrap px-4 py-3.5">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => setViewing(row)}
                            className="rounded-lg p-1.5 text-base-400 transition-colors hover:bg-base-800 hover:text-accent-400"
                            aria-label={`View ${row.name}`}
                          >
                            <Eye size={16} />
                          </button>
                          <button
                            onClick={() => openEdit(row)}
                            className="rounded-lg p-1.5 text-base-400 transition-colors hover:bg-base-800 hover:text-base-100"
                            aria-label={`Edit ${row.name}`}
                          >
                            <Pencil size={16} />
                          </button>
                          <button
                            onClick={() => setDeleting(row)}
                            className="rounded-lg p-1.5 text-base-400 transition-colors hover:bg-rose-500/10 hover:text-rose-500"
                            aria-label={`Delete ${row.name}`}
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </motion.tr>
                  ))
                )}
              </AnimatePresence>
            </tbody>
          </table>
        </div>
      </Card>

      {/* View student modal */}
      <Modal
        open={!!viewing}
        onClose={() => setViewing(null)}
        title="Student profile"
        description={viewing?.rollNo}
      >
        {viewing && (
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              {viewing.photo ? (
                <img src={viewing.photo} alt={viewing.name} className="h-16 w-16 rounded-xl object-cover" />
              ) : (
                <span
                  className="flex h-16 w-16 items-center justify-center rounded-xl font-display text-lg font-semibold text-base-950"
                  style={{ backgroundColor: viewing.avatarColor }}
                >
                  {initials(viewing.name)}
                </span>
              )}
              <div>
                <p className="font-display text-base font-semibold text-base-100">{viewing.name}</p>
                <p className="text-sm text-base-400">{viewing.email || "No email on file"}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 rounded-xl border border-base-700 bg-base-800/40 p-4 text-sm">
              <div>
                <p className="text-xs text-base-400">Department</p>
                <p className="text-base-100">{viewing.department}</p>
              </div>
              <div>
                <p className="text-xs text-base-400">Semester</p>
                <p className="font-mono text-base-100">{viewing.semester}</p>
              </div>
              <div>
                <p className="text-xs text-base-400">Registration date</p>
                <p className="font-mono text-base-100">{viewing.enrolledOn}</p>
              </div>
              <div>
                <p className="text-xs text-base-400">Status</p>
                <EnrollmentBadge status={viewing.enrollmentStatus} />
              </div>
            </div>
            <Button fullWidth variant="secondary" onClick={() => setViewing(null)}>
              Close
            </Button>
          </div>
        )}
      </Modal>

      {/* Edit student modal */}
      <Modal
        open={!!editing}
        onClose={() => setEditing(null)}
        title="Edit student"
        description={editing?.rollNo}
      >
        <div className="space-y-5">
          <StudentForm values={editValues} onChange={setEditValues} />
          <div className="flex justify-end gap-3">
            <Button variant="ghost" onClick={() => setEditing(null)}>
              Cancel
            </Button>
            <Button onClick={saveEdit}>Save changes</Button>
          </div>
        </div>
      </Modal>

      {/* Delete confirmation modal */}
      <Modal
        open={!!deleting}
        onClose={() => setDeleting(null)}
        title="Remove student"
        description="This only updates local UI state — no data is deleted on a server."
      >
        <div className="mb-5 flex items-center gap-3 rounded-xl border border-rose-500/25 bg-rose-500/10 p-3.5">
          <AlertTriangle className="shrink-0 text-rose-500" size={20} />
          <p className="text-sm text-base-200">
            Remove <span className="font-medium text-base-100">{deleting?.name}</span> ({deleting?.rollNo})
            from the students list?
          </p>
        </div>
        <div className="flex justify-end gap-3">
          <Button variant="ghost" onClick={() => setDeleting(null)}>
            Cancel
          </Button>
          <Button variant="danger" icon={<X size={16} />} onClick={confirmDelete}>
            Remove student
          </Button>
        </div>
      </Modal>
    </DashboardLayout>
  );
}
