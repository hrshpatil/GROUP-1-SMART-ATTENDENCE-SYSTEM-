import { AnimatePresence, motion } from "framer-motion";
import { Check, Loader2, Pause, Play, ScanFace, UserX, Video } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { DashboardLayout } from "../components/layout/DashboardLayout";
import { Badge } from "../components/ui/Badge";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { students } from "../data/dummyData";
import type { Student } from "../types";

type CameraState =
  | "idle"
  | "initializing"
  | "scanning"
  | "face_detected"
  | "recognizing"
  | "recognized"
  | "marked"
  | "unknown";

interface RecentEntry {
  key: string;
  student: Student;
  time: string;
  confidence: number;
}

type Tone = "idle" | "active" | "warn" | "success" | "danger";

const STATUS_META: Record<CameraState, { label: string; tone: Tone }> = {
  idle: { label: "Idle", tone: "idle" },
  initializing: { label: "Starting", tone: "active" },
  scanning: { label: "Scanning", tone: "active" },
  face_detected: { label: "Face detected", tone: "warn" },
  recognizing: { label: "Recognizing", tone: "warn" },
  recognized: { label: "Match found", tone: "success" },
  marked: { label: "Attendance marked", tone: "success" },
  unknown: { label: "Unknown face", tone: "danger" },
};

const TONE_PILL: Record<Tone, string> = {
  idle: "border-base-600 bg-base-800 text-base-400",
  active: "border-accent-500/25 bg-accent-500/10 text-accent-400",
  warn: "border-amber-500/25 bg-amber-500/10 text-amber-500",
  success: "border-emerald-500/25 bg-emerald-500/10 text-emerald-500",
  danger: "border-rose-500/25 bg-rose-500/10 text-rose-500",
};

const TONE_DOT: Record<Tone, string> = {
  idle: "bg-base-500",
  active: "bg-accent-500",
  warn: "bg-amber-500",
  success: "bg-emerald-500",
  danger: "bg-rose-500",
};

const WAITING_COPY: Partial<Record<CameraState, { title: string; sub: string }>> = {
  idle: { title: "Waiting for camera", sub: "Start the camera to begin live recognition." },
  initializing: { title: "Starting camera...", sub: "Initializing video stream." },
  scanning: { title: "Scanning for faces", sub: "Position yourself within the frame." },
  face_detected: { title: "Face detected", sub: "Preparing to analyze facial features." },
  recognizing: { title: "Recognizing...", sub: "Matching against enrolled student records." },
};

function initials(name: string): string {
  return name
    .trim()
    .split(/\s+/)
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

export default function LiveAttendance() {
  const [state, setState] = useState<CameraState>("idle");
  const [activeStudent, setActiveStudent] = useState<Student | null>(null);
  const [confidence, setConfidence] = useState(0);
  const [recent, setRecent] = useState<RecentEntry[]>([]);

  const runningRef = useRef(false);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);

  const schedule = (fn: () => void, ms: number) => {
    const t = setTimeout(fn, ms);
    timers.current.push(t);
    return t;
  };

  const clearTimers = () => {
    timers.current.forEach(clearTimeout);
    timers.current = [];
  };

  useEffect(() => {
    return () => {
      runningRef.current = false;
      clearTimers();
    };
  }, []);

  function pickStudent(): Student {
    return students[Math.floor(Math.random() * students.length)];
  }

  function runDetectionCycle() {
    if (!runningRef.current) return;
    setState("scanning");
    setActiveStudent(null);

    const detectDelay = 2200 + Math.random() * 1800;
    schedule(() => {
      if (!runningRef.current) return;
      setState("face_detected");

      schedule(() => {
        if (!runningRef.current) return;
        setState("recognizing");

        schedule(() => {
          if (!runningRef.current) return;
          const isKnown = Math.random() > 0.2;

          if (isKnown) {
            const student = pickStudent();
            const conf = Math.round((90 + Math.random() * 9.5) * 10) / 10;
            setActiveStudent(student);
            setConfidence(conf);
            setState("recognized");

            schedule(() => {
              if (!runningRef.current) return;
              setState("marked");
              setRecent((prev) =>
                [
                  {
                    key: `${student.id}-${Date.now()}`,
                    student,
                    time: new Date().toLocaleTimeString("en-US", {
                      hour: "2-digit",
                      minute: "2-digit",
                    }),
                    confidence: conf,
                  },
                  ...prev,
                ].slice(0, 6)
              );
              schedule(() => runDetectionCycle(), 2400);
            }, 900);
          } else {
            setState("unknown");
            schedule(() => runDetectionCycle(), 2000);
          }
        }, 1500);
      }, 900);
    }, detectDelay);
  }

  function handleStart() {
    if (runningRef.current) return;
    runningRef.current = true;
    setState("initializing");
    schedule(() => runDetectionCycle(), 700);
  }

  function handleStop() {
    runningRef.current = false;
    clearTimers();
    setState("idle");
    setActiveStudent(null);
    setConfidence(0);
  }

  const isRunning = state !== "idle";
  const meta = STATUS_META[state];
  const showBox = ["face_detected", "recognizing", "recognized", "marked", "unknown"].includes(state);
  const boxTone: Tone =
    state === "unknown" ? "danger" : state === "recognized" || state === "marked" ? "success" : "warn";
  const boxBorder: Record<Tone, string> = {
    idle: "border-base-600",
    active: "border-accent-500/70",
    warn: "border-amber-500/70",
    success: "border-emerald-500/70",
    danger: "border-rose-500/70",
  };
  const boxLabelClasses: Record<Tone, string> = {
    idle: "bg-base-800 text-base-400",
    active: "bg-accent-500/15 text-accent-400",
    warn: "bg-amber-500/15 text-amber-400",
    success: "bg-emerald-500/15 text-emerald-400",
    danger: "bg-rose-500/15 text-rose-400",
  };
  const boxLabel =
    state === "face_detected"
      ? "Detecting..."
      : state === "recognizing"
        ? "Recognizing..."
        : state === "unknown"
          ? "Unknown"
          : activeStudent
            ? activeStudent.name
            : "";

  return (
    <DashboardLayout title="Live Attendance" subtitle="Camera-based real-time attendance capture">
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
        {/* Left: camera */}
        <Card className="p-6 lg:col-span-3">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-display text-base font-semibold text-base-100">Camera Feed</h2>
            <span
              className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium ${TONE_PILL[meta.tone]}`}
            >
              <motion.span
                className={`h-1.5 w-1.5 rounded-full ${TONE_DOT[meta.tone]}`}
                animate={isRunning ? { opacity: [1, 0.35, 1], scale: [1, 1.35, 1] } : { opacity: 1, scale: 1 }}
                transition={{ duration: 1.6, repeat: isRunning ? Infinity : 0, ease: "easeInOut" }}
              />
              {meta.label}
            </span>
          </div>

          <div
            className={`corner-brackets relative flex aspect-video items-center justify-center overflow-hidden rounded-2xl border border-base-600 bg-base-950 ${isRunning ? "brackets-active" : ""}`}
          >
            <div className="scan-grid-bg absolute inset-0 opacity-50" />

            {/* Idle / initializing placeholder */}
            {(state === "idle" || state === "initializing") && (
              <div className="relative flex flex-col items-center gap-2 text-base-500">
                {state === "initializing" ? (
                  <Loader2 size={40} strokeWidth={1.5} className="animate-spin text-accent-400" />
                ) : (
                  <Video size={48} strokeWidth={1.5} />
                )}
                <p className="text-xs">
                  {state === "initializing" ? "Starting camera..." : "Live camera feed placeholder"}
                </p>
              </div>
            )}

            {/* Scanning sweep — camera on, no face yet */}
            {state === "scanning" && (
              <>
                <motion.div
                  className="absolute left-0 right-0 h-0.5 bg-accent-500/80 shadow-[0_0_12px_2px_var(--color-accent-glow)]"
                  initial={{ top: "6%" }}
                  animate={{ top: ["6%", "94%", "6%"] }}
                  transition={{ duration: 2.4, repeat: Infinity, ease: "easeInOut" }}
                />
                <div className="relative flex flex-col items-center gap-2 text-base-500">
                  <ScanFace size={44} strokeWidth={1.3} className="text-accent-500/50" />
                  <p className="text-xs">Scanning for faces...</p>
                </div>
              </>
            )}

            {/* Face bounding box overlay */}
            <AnimatePresence>
              {showBox && (
                <motion.div
                  key={state === "recognized" || state === "marked" ? "box-match" : state}
                  initial={{ opacity: 0, scale: 0.92 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.25 }}
                  className={`absolute left-[30%] top-[16%] h-40 w-32 rounded-lg border-2 ${boxBorder[boxTone]}`}
                >
                  {(state === "face_detected" || state === "recognizing") && (
                    <motion.div
                      className={`absolute inset-0 rounded-lg border-2 ${boxBorder[boxTone]}`}
                      animate={{ opacity: [0.9, 0.15, 0.9] }}
                      transition={{ duration: 1.1, repeat: Infinity, ease: "easeInOut" }}
                    />
                  )}
                  <span
                    className={`absolute -top-6 left-0 whitespace-nowrap rounded-md px-1.5 py-0.5 font-mono text-[10px] ${boxLabelClasses[boxTone]}`}
                  >
                    {boxLabel}
                  </span>

                  {state === "recognizing" && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Loader2 size={22} className="animate-spin text-amber-400" />
                    </div>
                  )}
                  {(state === "recognized" || state === "marked") && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <motion.div
                        initial={{ scale: 0, rotate: -20 }}
                        animate={{ scale: 1, rotate: 0 }}
                        transition={{ type: "spring", stiffness: 320, damping: 16 }}
                        className="rounded-full bg-emerald-500/15 p-1.5"
                      >
                        <Check size={20} className="text-emerald-400" />
                      </motion.div>
                    </div>
                  )}
                  {state === "unknown" && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <UserX size={22} className="text-rose-400" />
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>

            {/* Success flash when attendance is marked */}
            <AnimatePresence>
              {state === "marked" && (
                <motion.div
                  key="success-flash"
                  className="pointer-events-none absolute inset-0 bg-emerald-500/10"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: [0, 0.55, 0] }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.9, ease: "easeOut" }}
                />
              )}
            </AnimatePresence>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-3">
            <Button
              fullWidth
              variant="primary"
              icon={<Play size={17} />}
              disabled={isRunning}
              onClick={handleStart}
            >
              Start Camera
            </Button>
            <Button
              fullWidth
              variant="danger"
              icon={<Pause size={17} />}
              disabled={!isRunning}
              onClick={handleStop}
            >
              Stop Camera
            </Button>
          </div>
          <p className="mt-3 text-center text-xs text-base-400">
            Face detection and recognition are simulated for this UI preview — camera and OpenCV
            integration are not implemented yet.
          </p>
        </Card>

        {/* Right: recognition + recent */}
        <div className="flex flex-col gap-6 lg:col-span-2">
          <Card className="p-6">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-base font-semibold text-base-100">Live Recognition</h2>
              <ScanFace size={17} className="text-base-400" />
            </div>

            <AnimatePresence mode="wait">
              {activeStudent && (state === "recognized" || state === "marked") ? (
                <motion.div
                  key={`match-${activeStudent.id}-${state}`}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  transition={{ duration: 0.2 }}
                  className="space-y-4"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl font-display text-lg font-semibold"
                      style={{
                        backgroundColor: `${activeStudent.avatarColor}22`,
                        color: activeStudent.avatarColor,
                      }}
                    >
                      {initials(activeStudent.name)}
                    </div>
                    <div className="min-w-0">
                      <p className="truncate font-display text-sm font-semibold text-base-100">
                        {activeStudent.name}
                      </p>
                      <p className="font-mono text-xs text-base-400">{activeStudent.rollNo}</p>
                    </div>
                  </div>

                  <div>
                    <div className="mb-1 flex items-center justify-between text-xs text-base-400">
                      <span>Confidence</span>
                      <span className="font-mono text-accent-400">{confidence}%</span>
                    </div>
                    <div className="h-1.5 w-full overflow-hidden rounded-full bg-base-800">
                      <motion.div
                        className="h-full rounded-full bg-accent-500"
                        initial={{ width: 0 }}
                        animate={{ width: `${confidence}%` }}
                        transition={{ duration: 0.5, ease: "easeOut" }}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="rounded-xl border border-base-700 bg-base-800/40 px-3 py-2.5">
                      <p className="text-base-400">Recognition</p>
                      <p className="mt-1 font-medium text-emerald-500">Matched</p>
                    </div>
                    <div className="rounded-xl border border-base-700 bg-base-800/40 px-3 py-2.5">
                      <p className="text-base-400">Attendance</p>
                      <p
                        className={`mt-1 flex items-center gap-1 font-medium ${state === "marked" ? "text-emerald-500" : "text-amber-500"}`}
                      >
                        {state === "marked" ? (
                          <>
                            <Check size={12} /> Marked
                          </>
                        ) : (
                          <>
                            <Loader2 size={12} className="animate-spin" /> Marking...
                          </>
                        )}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ) : state === "unknown" ? (
                <motion.div
                  key="unknown"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="flex flex-col items-center gap-2 rounded-xl border border-rose-500/20 bg-rose-500/5 px-4 py-8 text-center"
                >
                  <UserX size={26} className="text-rose-500" />
                  <p className="text-sm font-medium text-rose-500">Unknown face</p>
                  <p className="text-xs text-base-400">No matching student profile found.</p>
                </motion.div>
              ) : (
                <motion.div
                  key="waiting"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="flex flex-col items-center gap-2 rounded-xl border border-base-700 bg-base-800/30 px-4 py-8 text-center"
                >
                  {state === "recognizing" ? (
                    <Loader2 size={26} className="animate-spin text-accent-400" />
                  ) : (
                    <ScanFace size={26} className="text-base-500" />
                  )}
                  <p className="text-sm font-medium text-base-300">{WAITING_COPY[state]?.title}</p>
                  <p className="text-xs text-base-500">{WAITING_COPY[state]?.sub}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </Card>

          <Card className="flex flex-1 flex-col p-6">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-base font-semibold text-base-100">Recent Attendance</h2>
              <span className="font-mono text-xs text-base-400">{recent.length} marked</span>
            </div>

            <div className="max-h-80 flex-1 space-y-2 overflow-y-auto">
              {recent.length === 0 && (
                <p className="py-8 text-center text-xs text-base-500">
                  No attendance marked yet this session.
                </p>
              )}
              <AnimatePresence initial={false}>
                {recent.map((r) => (
                  <motion.div
                    key={r.key}
                    layout
                    initial={{ opacity: 0, x: 16 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.25 }}
                    className="flex items-center justify-between rounded-xl border border-base-700 bg-base-800/40 px-3.5 py-2.5"
                  >
                    <div className="flex min-w-0 items-center gap-2.5">
                      <div
                        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-xs font-semibold"
                        style={{
                          backgroundColor: `${r.student.avatarColor}22`,
                          color: r.student.avatarColor,
                        }}
                      >
                        {initials(r.student.name)}
                      </div>
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium text-base-100">{r.student.name}</p>
                        <p className="font-mono text-xs text-base-400">
                          {r.student.rollNo} &middot; {r.time}
                        </p>
                      </div>
                    </div>
                    <Badge status="present" />
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
