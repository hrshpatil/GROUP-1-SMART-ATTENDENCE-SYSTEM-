import { CheckCircle2, ClipboardList, ScanFace, UserPlus, Users, XCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { AttendanceChart } from "../components/dashboard/AttendanceChart";
import { StatCard } from "../components/dashboard/StatCard";
import { DashboardLayout } from "../components/layout/DashboardLayout";
import { Badge } from "../components/ui/Badge";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { Table, type Column } from "../components/ui/Table";
import {
  attendancePercentage,
  attendanceRecords,
  absentToday,
  presentToday,
  totalStudents,
} from "../data/dummyData";
import type { AttendanceRecord } from "../types";

const columns: Column<AttendanceRecord>[] = [
  {
    header: "Student",
    accessor: (row) => (
      <div>
        <p className="font-medium text-base-100">{row.studentName}</p>
        <p className="font-mono text-xs text-base-400">{row.rollNo}</p>
      </div>
    ),
  },
  { header: "Department", accessor: (row) => row.department },
  { header: "Time", accessor: (row) => <span className="font-mono">{row.time}</span> },
  {
    header: "Confidence",
    accessor: (row) => <span className="font-mono text-accent-400">{row.confidence}%</span>,
  },
  { header: "Status", accessor: (row) => <Badge status={row.status} /> },
];

export default function Dashboard() {
  const navigate = useNavigate();

  return (
    <DashboardLayout title="Dashboard" subtitle="Overview of today's attendance activity">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Total Students" value={totalStudents.toString()} icon={Users} accent="accent" />
        <StatCard
          label="Present Today"
          value={presentToday.toString()}
          icon={CheckCircle2}
          accent="emerald"
          trend={{ value: "4.2%", positive: true }}
        />
        <StatCard
          label="Absent Today"
          value={absentToday.toString()}
          icon={XCircle}
          accent="rose"
          trend={{ value: "1.1%", positive: false }}
        />
        <StatCard
          label="Attendance %"
          value={`${attendancePercentage}%`}
          icon={ScanFace}
          accent="amber"
        />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="p-5 xl:col-span-2">
          <div className="mb-1 flex items-center justify-between">
            <h2 className="font-display text-base font-semibold text-base-100">
              Weekly attendance overview
            </h2>
            <span className="font-mono text-xs text-base-400">LAST 6 DAYS</span>
          </div>
          <AttendanceChart />
        </Card>

        <Card className="flex flex-col justify-between p-5">
          <div>
            <h2 className="mb-4 font-display text-base font-semibold text-base-100">Quick actions</h2>
            <div className="space-y-3">
              <Button fullWidth icon={<UserPlus size={17} />} onClick={() => navigate("/register")}>
                Register Student
              </Button>
              <Button
                fullWidth
                variant="secondary"
                icon={<ScanFace size={17} />}
                onClick={() => navigate("/live-attendance")}
              >
                Start Attendance
              </Button>
              <Button
                fullWidth
                variant="ghost"
                icon={<ClipboardList size={17} />}
                onClick={() => navigate("/records")}
              >
                View Records
              </Button>
            </div>
          </div>

          <div className="mt-6 rounded-xl border border-base-700 bg-base-800/50 p-4">
            <p className="font-mono text-[10px] uppercase tracking-wide text-base-400">Next class</p>
            <p className="mt-1 text-sm font-medium text-base-100">Digital Image Processing</p>
            <p className="text-xs text-base-400">Lab 4 &middot; 11:00 AM &middot; CS-301</p>
          </div>
        </Card>
      </div>

      <Card className="mt-6 p-5">
        <div className="mb-1 flex items-center justify-between">
          <h2 className="font-display text-base font-semibold text-base-100">Recent attendance</h2>
          <Button variant="ghost" size="sm" onClick={() => navigate("/records")}>
            View all
          </Button>
        </div>
        <Table
          columns={columns}
          data={attendanceRecords.slice(0, 6)}
          keyExtractor={(row) => row.id}
        />
      </Card>
    </DashboardLayout>
  );
}
