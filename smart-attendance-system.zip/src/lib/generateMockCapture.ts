/**
 * Generates a local placeholder "captured photo" using the Canvas API.
 *
 * This purely simulates a photo capture for UI/demo purposes — no camera
 * or OpenCV integration. It draws a soft gradient bust with the student's
 * initials so the "Register Student" flow has something real to preview,
 * retake, and submit.
 */
export function generateMockCapture(name: string, color: string): string {
  const size = 480;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");
  if (!ctx) return "";

  // Background gradient (studio-backdrop feel)
  const bg = ctx.createLinearGradient(0, 0, size, size);
  bg.addColorStop(0, "#111a2c");
  bg.addColorStop(1, "#0b1220");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, size, size);

  // Subtle scan grid
  ctx.strokeStyle = "rgba(41, 217, 194, 0.08)";
  ctx.lineWidth = 1;
  for (let x = 0; x < size; x += 24) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, size);
    ctx.stroke();
  }
  for (let y = 0; y < size; y += 24) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(size, y);
    ctx.stroke();
  }

  // Avatar circle
  const cx = size / 2;
  const cy = size / 2;
  const r = size * 0.32;
  const circleGradient = ctx.createRadialGradient(cx, cy - r * 0.3, r * 0.2, cx, cy, r);
  circleGradient.addColorStop(0, color);
  circleGradient.addColorStop(1, shade(color, -25));
  ctx.fillStyle = circleGradient;
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fill();

  // Initials
  const initials = name
    .trim()
    .split(/\s+/)
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
  ctx.fillStyle = "#0b1220";
  ctx.font = `600 ${Math.round(r * 0.8)}px "Space Grotesk", sans-serif`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(initials || "?", cx, cy + r * 0.05);

  // Corner detection brackets, echoing the app's scan motif
  ctx.strokeStyle = "rgba(41, 217, 194, 0.55)";
  ctx.lineWidth = 3;
  const m = 28;
  const b = 26;
  const corners: [number, number, number, number][] = [
    [m, m, 1, 1],
    [size - m, m, -1, 1],
    [m, size - m, 1, -1],
    [size - m, size - m, -1, -1],
  ];
  corners.forEach(([x, y, dx, dy]) => {
    ctx.beginPath();
    ctx.moveTo(x, y + b * dy);
    ctx.lineTo(x, y);
    ctx.lineTo(x + b * dx, y);
    ctx.stroke();
  });

  return canvas.toDataURL("image/png");
}

function shade(hex: string, percent: number): string {
  const num = parseInt(hex.replace("#", ""), 16);
  const r = Math.min(255, Math.max(0, ((num >> 16) & 0xff) + percent));
  const g = Math.min(255, Math.max(0, ((num >> 8) & 0xff) + percent));
  const b = Math.min(255, Math.max(0, (num & 0xff) + percent));
  return `rgb(${r}, ${g}, ${b})`;
}
