/**
 * Minimal client for the FastAPI face-detection backend.
 *
 * Not wired into any page yet — the Live Attendance UI still runs its
 * mock camera/recognition cycle. This exists so a future integration
 * can call the backend without re-plumbing configuration.
 *
 * Configure the backend URL via VITE_API_BASE_URL (see .env.example).
 */

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8000";

export interface HealthResponse {
  status: string;
  service: string;
  version: string;
  opencv_version: string;
  timestamp: string;
}

export interface FaceBox {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface PreparedFace {
  width: number;
  height: number;
  status: string;
}

export interface FaceDetectionResponse {
  success: boolean;
  face_count: number;
  faces: FaceBox[];
  image_width: number;
  image_height: number;
  processing_time_ms: number;
  annotated_image: string | null;
  prepared_faces: PreparedFace[];
}

export interface ApiErrorBody {
  success: false;
  error: string;
  detail?: string;
}

export class ApiError extends Error {
  status: number;
  code: string;

  constructor(status: number, body: ApiErrorBody) {
    super(body.detail || body.error || `Request failed with status ${status}`);
    this.status = status;
    this.code = body.error;
  }
}

async function parseOrThrow<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const body = (await response.json().catch(() => null)) as ApiErrorBody | null;
    throw new ApiError(response.status, body ?? { success: false, error: "unknown_error" });
  }
  return response.json() as Promise<T>;
}

/** GET /api/health */
export async function checkHealth(): Promise<HealthResponse> {
  const response = await fetch(`${API_BASE_URL}/api/health`);
  return parseOrThrow<HealthResponse>(response);
}

/**
 * POST /api/face/detect/base64
 * Send a data URL (e.g. from a <canvas> capture) for face detection.
 */
export async function detectFacesFromDataUrl(
  imageDataUrl: string,
  returnImage = true
): Promise<FaceDetectionResponse> {
  const response = await fetch(`${API_BASE_URL}/api/face/detect/base64`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ image: imageDataUrl, return_image: returnImage }),
  });
  return parseOrThrow<FaceDetectionResponse>(response);
}

/** POST /api/face/detect — multipart file upload variant. */
export async function detectFacesFromFile(
  file: File | Blob,
  returnImage = true
): Promise<FaceDetectionResponse> {
  const form = new FormData();
  form.append("file", file);
  const response = await fetch(
    `${API_BASE_URL}/api/face/detect?return_image=${returnImage}`,
    { method: "POST", body: form }
  );
  return parseOrThrow<FaceDetectionResponse>(response);
}
