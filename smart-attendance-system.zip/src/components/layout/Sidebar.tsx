import {
  LayoutDashboard,
  Users,
  UserPlus,
  ScanFace,
  ClipboardList,
  BarChart3,
  Settings,
  ScanEye,
  X,
} from "lucide-react";
import { NavLink } from "react-router-dom";

const navItems = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard, end: true },
  { to: "/students", label: "Students", icon: Users },
  { to: "/register", label: "Register Student", icon: UserPlus },
  { to: "/live-attendance", label: "Live Attendance", icon: ScanFace },
  { to: "/records", label: "Attendance Records", icon: ClipboardList },
  { to: "/reports", label: "Reports", icon: BarChart3 },
  { to: "/settings", label: "Settings", icon: Settings },
];

interface SidebarProps {
  open: boolean;
  onClose: () => void;
}

export function Sidebar({ open, onClose }: SidebarProps) {
  return (
    <>
      {/* Mobile backdrop */}
      {open && (
        <div
          className="fixed inset-0 z-30 bg-base-950/70 backdrop-blur-sm lg:hidden"
          onClick={onClose}
        />
      )}

      <aside
        className={[
          "fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-base-700/80 bg-base-900/95 backdrop-blur-xl",
          "transition-transform duration-200 lg:translate-x-0",
          open ? "translate-x-0" : "-translate-x-full",
        ].join(" ")}
      >
        <div className="flex items-center justify-between px-5 py-5">
          <div className="flex items-center gap-2.5">
            <div className="corner-brackets brackets-active flex h-9 w-9 items-center justify-center rounded-lg border border-accent-500/40 bg-accent-500/10 text-accent-500">
              <ScanEye size={19} strokeWidth={2} />
            </div>
            <div className="leading-tight">
              <p className="font-display text-[15px] font-semibold text-base-100">Smart Attendance</p>
              <p className="font-mono text-[10px] tracking-wide text-base-400">FACE RECOGNITION SYSTEM</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-base-300 hover:bg-base-800 lg:hidden"
            aria-label="Close sidebar"
          >
            <X size={18} />
          </button>
        </div>

        <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-2">
          {navItems.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              onClick={onClose}
              className={({ isActive }) =>
                [
                  "group relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors",
                  isActive
                    ? "bg-accent-500/10 text-accent-400"
                    : "text-base-300 hover:bg-base-800 hover:text-base-100",
                ].join(" ")
              }
            >
              {({ isActive }) => (
                <>
                  {isActive && (
                    <span className="absolute left-0 top-1/2 h-5 w-[3px] -translate-y-1/2 rounded-r-full bg-accent-500" />
                  )}
                  <Icon size={18} strokeWidth={2} />
                  {label}
                </>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="m-3 rounded-xl border border-base-700 bg-base-800/60 p-3.5">
          <p className="font-mono text-[10px] uppercase tracking-wide text-base-400">System status</p>
          <div className="mt-2 flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-500 opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
            </span>
            <span className="text-xs text-base-200">Camera module idle</span>
          </div>
        </div>
      </aside>
    </>
  );
}
