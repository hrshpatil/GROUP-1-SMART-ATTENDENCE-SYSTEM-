import { Bell, Menu, Moon, Search, Sun } from "lucide-react";
import { useTheme } from "../../context/ThemeContext";

interface HeaderProps {
  title: string;
  subtitle?: string;
  onMenuClick: () => void;
}

export function Header({ title, subtitle, onMenuClick }: HeaderProps) {
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="sticky top-0 z-20 flex items-center gap-4 border-b border-base-700/80 bg-base-950/80 px-4 py-4 backdrop-blur-xl sm:px-6">
      <button
        onClick={onMenuClick}
        className="rounded-lg p-2 text-base-300 hover:bg-base-800 lg:hidden"
        aria-label="Open sidebar"
      >
        <Menu size={20} />
      </button>

      <div className="min-w-0 flex-1">
        <h1 className="truncate font-display text-lg font-semibold text-base-100 sm:text-xl">
          {title}
        </h1>
        {subtitle && <p className="hidden text-sm text-base-400 sm:block">{subtitle}</p>}
      </div>

      <div className="relative hidden max-w-xs flex-1 md:block">
        <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-base-400" />
        <input
          type="text"
          placeholder="Search students, records..."
          className="w-full rounded-xl border border-base-700 bg-base-800/60 py-2 pl-9 pr-3 text-sm text-base-100 placeholder:text-base-400 outline-none transition-colors focus:border-accent-500/60 focus:bg-base-800"
        />
      </div>

      <button
        className="hidden rounded-lg p-2 text-base-300 hover:bg-base-800 md:hidden"
        aria-label="Search"
      >
        <Search size={19} />
      </button>

      <button
        className="relative rounded-lg p-2 text-base-300 transition-colors hover:bg-base-800 hover:text-base-100"
        aria-label="Notifications"
      >
        <Bell size={19} />
        <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-accent-500" />
      </button>

      <button
        onClick={toggleTheme}
        className="rounded-lg p-2 text-base-300 transition-colors hover:bg-base-800 hover:text-base-100"
        aria-label="Toggle theme"
      >
        {theme === "dark" ? <Sun size={19} /> : <Moon size={19} />}
      </button>

      <button className="flex items-center gap-2.5 rounded-xl border border-base-700 bg-base-800/60 py-1.5 pl-1.5 pr-3 transition-colors hover:border-accent-500/40">
        <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-accent-500/15 font-display text-xs font-semibold text-accent-400">
          AK
        </span>
        <span className="hidden text-left sm:block">
          <span className="block text-xs font-medium text-base-100">Prof. Anil Kulkarni</span>
          <span className="block text-[10px] text-base-400">Administrator</span>
        </span>
      </button>
    </header>
  );
}
