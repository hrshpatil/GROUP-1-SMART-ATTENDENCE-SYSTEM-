import { type InputHTMLAttributes, type ReactNode, forwardRef } from "react";

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  icon?: ReactNode;
  hint?: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ label, icon, hint, className = "", id, ...rest }, ref) => {
    return (
      <label className="block" htmlFor={id}>
        {label && (
          <span className="mb-1.5 block text-sm font-medium text-base-200">{label}</span>
        )}
        <div className="relative">
          {icon && (
            <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-base-400">
              {icon}
            </span>
          )}
          <input
            ref={ref}
            id={id}
            className={[
              "w-full rounded-xl border border-base-600 bg-base-800/60 py-2.5 text-sm text-base-100",
              "placeholder:text-base-400 outline-none transition-colors",
              "focus:border-accent-500/70 focus:bg-base-800",
              icon ? "pl-9 pr-3" : "px-3",
              className,
            ].join(" ")}
            {...rest}
          />
        </div>
        {hint && <span className="mt-1.5 block text-xs text-base-400">{hint}</span>}
      </label>
    );
  }
);
Input.displayName = "Input";
