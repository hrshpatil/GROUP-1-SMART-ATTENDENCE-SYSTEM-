import type { HTMLAttributes, ReactNode } from "react";

interface CardProps extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  hover?: boolean;
  brackets?: boolean;
}

export function Card({ children, hover = false, brackets = false, className = "", ...rest }: CardProps) {
  return (
    <div
      className={[
        "rounded-2xl border border-base-700/80 bg-base-900/60 backdrop-blur-xl",
        "shadow-[0_1px_0_0_rgba(255,255,255,0.03)_inset]",
        hover ? "transition-all duration-200 hover:border-accent-500/40 hover:bg-base-900/80" : "",
        brackets ? "corner-brackets" : "",
        className,
      ].join(" ")}
      {...rest}
    >
      {children}
    </div>
  );
}
