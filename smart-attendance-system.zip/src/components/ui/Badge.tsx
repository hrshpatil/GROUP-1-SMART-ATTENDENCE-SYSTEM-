import type { AttendanceStatus } from "../../types";

const config: Record<AttendanceStatus, { label: string; classes: string; dot: string }> = {
  present: {
    label: "Present",
    classes: "bg-emerald-500/10 text-emerald-500 border-emerald-500/25",
    dot: "bg-emerald-500",
  },
  absent: {
    label: "Absent",
    classes: "bg-rose-500/10 text-rose-500 border-rose-500/25",
    dot: "bg-rose-500",
  },
  late: {
    label: "Late",
    classes: "bg-amber-500/10 text-amber-500 border-amber-500/25",
    dot: "bg-amber-500",
  },
};

export function Badge({ status }: { status: AttendanceStatus }) {
  const c = config[status];
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium ${c.classes}`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${c.dot}`} />
      {c.label}
    </span>
  );
}
