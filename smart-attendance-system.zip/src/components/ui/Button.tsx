import { type ButtonHTMLAttributes, type ReactNode, forwardRef } from "react";

type Variant = "primary" | "secondary" | "ghost" | "danger";
type Size = "sm" | "md" | "lg";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  icon?: ReactNode;
  fullWidth?: boolean;
}

const variantClasses: Record<Variant, string> = {
  primary:
    "bg-accent-500 text-base-950 hover:bg-accent-400 shadow-[0_0_0_1px_rgba(41,217,194,0.4)] hover:shadow-[0_0_20px_-2px_var(--color-accent-glow)]",
  secondary:
    "bg-base-800 text-base-100 border border-base-600 hover:border-accent-500/60 hover:bg-base-700",
  ghost:
    "bg-transparent text-base-200 hover:bg-base-800 border border-transparent hover:border-base-600",
  danger:
    "bg-rose-500/10 text-rose-500 border border-rose-500/30 hover:bg-rose-500/20",
};

const sizeClasses: Record<Size, string> = {
  sm: "text-xs px-3 py-1.5 gap-1.5 rounded-lg",
  md: "text-sm px-4 py-2.5 gap-2 rounded-xl",
  lg: "text-sm px-5 py-3 gap-2 rounded-xl",
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    { variant = "primary", size = "md", icon, fullWidth, className = "", children, ...rest },
    ref
  ) => {
    return (
      <button
        ref={ref}
        className={`inline-flex items-center justify-center font-medium transition-all duration-200 active:scale-[0.97] disabled:opacity-50 disabled:pointer-events-none ${variantClasses[variant]} ${sizeClasses[size]} ${fullWidth ? "w-full" : ""} ${className}`}
        {...rest}
      >
        {icon}
        {children}
      </button>
    );
  }
);
Button.displayName = "Button";
