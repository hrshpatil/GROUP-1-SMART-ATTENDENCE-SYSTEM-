import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { weeklyAttendance } from "../../data/dummyData";

export function AttendanceChart() {
  return (
    <div className="h-72 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={weeklyAttendance} margin={{ top: 10, right: 10, left: -18, bottom: 0 }}>
          <defs>
            <linearGradient id="presentFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#29d9c2" stopOpacity={0.35} />
              <stop offset="100%" stopColor="#29d9c2" stopOpacity={0} />
            </linearGradient>
            <linearGradient id="absentFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#f2685f" stopOpacity={0.25} />
              <stop offset="100%" stopColor="#f2685f" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid vertical={false} stroke="#182238" />
          <XAxis
            dataKey="day"
            axisLine={false}
            tickLine={false}
            tick={{ fill: "#8a93a6", fontSize: 12, fontFamily: "JetBrains Mono" }}
          />
          <YAxis
            axisLine={false}
            tickLine={false}
            tick={{ fill: "#8a93a6", fontSize: 12, fontFamily: "JetBrains Mono" }}
            width={32}
          />
          <Tooltip
            contentStyle={{
              background: "#111a2c",
              border: "1px solid #24304a",
              borderRadius: "12px",
              fontSize: "12px",
              fontFamily: "Inter",
            }}
            labelStyle={{ color: "#e8ecf1", fontWeight: 600, marginBottom: 4 }}
          />
          <Area
            type="monotone"
            dataKey="present"
            name="Present"
            stroke="#29d9c2"
            strokeWidth={2}
            fill="url(#presentFill)"
          />
          <Area
            type="monotone"
            dataKey="absent"
            name="Absent"
            stroke="#f2685f"
            strokeWidth={2}
            fill="url(#absentFill)"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
