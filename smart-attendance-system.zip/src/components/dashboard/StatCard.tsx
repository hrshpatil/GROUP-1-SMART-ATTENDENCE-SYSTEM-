import type { LucideIcon } from "lucide-react";
import { Card } from "../ui/Card";

interface StatCardProps {
  label: string;
  value: string;
  icon: LucideIcon;
  trend?: { value: string; positive: boolean };
  accent?: "accent" | "emerald" | "rose" | "amber";
}

const accentMap = {
  accent: "text-accent-400 bg-accent-500/10 border-accent-500/25",
  emerald: "text-emerald-500 bg-emerald-500/10 border-emerald-500/25",
  rose: "text-rose-500 bg-rose-500/10 border-rose-500/25",
  amber: "text-amber-500 bg-amber-500/10 border-amber-500/25",
};

export function StatCard({ label, value, icon: Icon, trend, accent = "accent" }: StatCardProps) {
  return (
    <Card hover brackets className="p-5">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-base-400">{label}</p>
          <p className="mt-2 font-mono text-3xl font-semibold text-base-100">{value}</p>
        </div>
        <div className={`flex h-10 w-10 items-center justify-center rounded-xl border ${accentMap[accent]}`}>
          <Icon size={19} strokeWidth={2} />
        </div>
      </div>
      {trend && (
        <p className={`mt-3 text-xs font-medium ${trend.positive ? "text-emerald-500" : "text-rose-500"}`}>
          {trend.positive ? "↑" : "↓"} {trend.value} vs last week
        </p>
      )}
    </Card>
  );
}
